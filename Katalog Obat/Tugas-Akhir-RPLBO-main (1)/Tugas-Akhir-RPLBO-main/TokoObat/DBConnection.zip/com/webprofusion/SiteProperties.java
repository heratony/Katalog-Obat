package com.webprofusion;

import java.io.*;
import java.util.*;

public class SiteProperties{

	private static String AppPath;
	private static String LoginPage;
	private static int DBEngine=0; //0= MSSQL; 1= MYSQL;
	private static String DBDriverName;
	private static String DBConnStr;
	private static String DBUsername;
	private static String DBPassword;
	private static String UploadFolder;

	private static String mailhost;
	static boolean propertiesloaded=false;

	public String getDBDriverName()
	{
		return DBDriverName;
	}

	public int getDBEngine()
	{
		return DBEngine;
	}

	public String getDBConnStr()
	{
		return DBConnStr;
	}

	public String getDBPassword()
	{
		return DBPassword;
	}

	public String getDBUsername()
	{
		return DBUsername;
	}

	public String getMailhost(){
		return mailhost;
	}

	public String getUploadFolder()
	{
		return UploadFolder;
	}
	public String getAppPath()
	{
		return AppPath;
	}

	public String getLoginPage()
	{
		return LoginPage;
	}



	public void initSiteProperties()
	{

		FileInputStream propIn = null;
		try{
			propIn = new FileInputStream(AppPath+"/Site.properties");
			Properties properties = new Properties();
			properties.load(propIn);
			propIn.close();

			DBDriverName=properties.getProperty("dbdrivername");
			DBConnStr=properties.getProperty("dbconnstr");
			DBUsername=properties.getProperty("dbusername");
			DBPassword=properties.getProperty("dbpassword");
			mailhost=properties.getProperty("mailhost");
			UploadFolder=properties.getProperty("uploadfolder");
			LoginPage=properties.getProperty("loginpage");
			String tmpDBEngine=properties.getProperty("dbengine");
			if (tmpDBEngine!=null) DBEngine=Integer.parseInt(tmpDBEngine);
			else DBEngine=0;

			properties=null;
			propertiesloaded=true;
			//System.out.println("Loading site properties::");

		}catch(Exception e){
			System.out.println("Panic. Failed to load Site Properties."+e.toString());
		}


	}

	//use this contructor to specify the path to the base of the application (where properties file is..)
	public SiteProperties(String path)
	{
		if (propertiesloaded) return; //only need to load properties file once since member variables are static and visible to all instances..
		//System.out.println(path);
		AppPath=path;
		initSiteProperties();
	}

	//use this contructor and the site properties will be reloaded (unless they have already been loaded through a call to this contructor from another instance)
	public SiteProperties()
	{

		if (propertiesloaded) return; //only need to load properties file once since member variables are static and visible to all instances..

		//if properties not already loaded then we need to know the path to the properties file so use the default..
		AppPath="";
		initSiteProperties();
	}


}