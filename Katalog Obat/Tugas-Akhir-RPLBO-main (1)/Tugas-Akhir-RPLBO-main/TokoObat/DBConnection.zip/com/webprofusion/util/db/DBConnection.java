// ===================================================================
// File:    DBConnection.java
// Author:  Christopher Cook
// Date:    22/11/1999
// Purpose: generic Database connection class-connects to db defined in SiteProperties by default
// version 	1.03
// ====================================================================

package com.webprofusion.util.db;

import java.io.*;
import java.sql.*;
import com.webprofusion.SiteProperties;


/**
* <b>General purpose database Connection object</b>
<br><b>Example:</b><br>
<pre>
			DBConnection dbconn= new DBConnection();
			dbconn.open();
			dbconn.openQueryRS("select RTRIM(Name) as Name from Users");

			String strName;

			while(dbconn.rs.next()) {
				strName = dbconn.rs.getString("Name");
				System.writeln(strName);
			}
			dbconn.closeQueryRS();
			dbconn.close();
</pre>
*/
public class DBConnection  {

	public static int MSSQL=0;
	public static int MYSQL=1;

	SiteProperties siteprops=new SiteProperties();
	int dbengine=siteprops.getDBEngine();

	Connection con =null;
	Statement stmt = null;

	/** result set from the most recent openQueryRS call
    */
    public ResultSet rs =null;
  	public boolean connectionReady=false;


	/**
	* <b>Opens default Database Connection to the BrandBuilders DB </b>
	*/
	public void open()
	{
		connectionReady=false;
		try {

			Class.forName(siteprops.getDBDriverName());
			con = DriverManager.getConnection(siteprops.getDBConnStr(),siteprops.getDBUsername(),siteprops.getDBPassword());

		} catch(ClassNotFoundException e) {
			System.out.println("Couldn't load database driver: " + e.getMessage());
		} catch(SQLException e) {
			System.out.println(siteprops.getDBConnStr()+" "+siteprops.getDBUsername()+" "+siteprops.getDBPassword()+"SQLException caught (opening db con): " + e.getMessage());
		}
		catch (NullPointerException e){
			System.out.println(siteprops.getDBConnStr()+" "+siteprops.getDBUsername()+" "+siteprops.getDBPassword()+" can't get database driver.. (opening db con): " + e.getMessage());
		}

		if (con!=null) connectionReady=true;

	}

	/**
	* <b>Closes current database connection</b>
	*/
	public void close()
	{
		try {
			if(con !=null) con.close();
		}
		catch (SQLException e) {
			System.out.println("SQLException caught (closing db conn): " + e.getMessage());
		}
		connectionReady=false;
	}

	public boolean next()
	{
		try {
			return rs.next();
		} catch (SQLException e) {
			System.err.println(e.toString()+": Failed to get next record in ResultSet.");
		}
		return false;
	}

	public String getString(String param)
	{
		try {
			return rs.getString(param);
		} catch (SQLException e) {
			System.err.println(e.toString()+": Failed to get parameter from result set.");
		}
		return null;
	}


	/** <b>creates a new statement,Performs the given guery, closes the statement</b>
         * @param strSQL sql query string
         */
	public void executeUpdate(String strSQL)
	{
    	try {
    		stmt=con.createStatement();
    	} catch (SQLException e) {
    		System.out.println("SQLException caught: (create statement )" + e.getMessage());
    	}

    	try {
    		stmt.executeUpdate(strSQL);
    		if (stmt!=null) stmt.close();
    	} catch (SQLException e) {
    		System.out.println("SQLException caught: (executing update )"+strSQL + e.getMessage());
    	}
	}


	/** <b>Creates a new statement and result set for a given SQL query</b>
         * @param strSQL sql query string
         * @return result set from the succesful query
         */

	public ResultSet openQueryRS(String strSQL)
	{

		try {
			if (con!=null) stmt=con.createStatement();
			else System.out.println("Cant create statemnt -null connection to DB (openQueryRS)");

		} catch (SQLException e) {
			System.out.println("SQLException caught: (opening query rs-create statement "+strSQL+"))" + e.getMessage());
			return null;
		}

		try {

			if (stmt!=null) rs = stmt.executeQuery(strSQL);
			else System.out.println("Cant execute query or open result set as the statement is null ");

		} catch (SQLException e) {
			System.out.println("SQLException caught: (opening query rs-executing query))" + e.getMessage());
			return null;
		}

		return rs;
	}

	/**
	* <b>Disposes of the current result set and statement.</b>
	*/
	public void closeQueryRS()
	{
		try {
			if (rs!=null) rs.close();
			if (stmt!=null) stmt.close();
		} catch (SQLException e) {
			System.out.println("SQLException caught: (closing query rs) " + e.getMessage());
		}

	}

	/**
	* <b>Creates SQL Date string for inserts from given day,month & year</b>
	*/
	public String getSQLDateString(int day,int month,int year)
	{
		//SQL Server specific formatting of Date string in to yyyymmdd format string for inserts..
		String datestring=year+"";
		if (month<10) datestring+="0"+month;
		else datestring+=month;

		if (day<10) datestring+="0"+day;
		else datestring+=day;
		return datestring;
	}

	public String getCurrentDateSQL()
	{
		if (dbengine==MYSQL) return "NOW()";
		if (dbengine==MSSQL) return "GETDATE()";

		return "GETDATE()";
	}

	public String getFormattedDateSQL(String datefield)
	{
		if (dbengine==MYSQL) return "DATE_FORMAT("+datefield+",'%D %b %Y')";
		if (dbengine==MSSQL) return "CONVERT(char(12),"+datefield+",106)";

		return "CONVERT(char(12),"+datefield+",106)";
	}

	public String getDatePartSQL(String datefield,String part)
	{
		if (part.equals("day"))
		{
			if (dbengine==MYSQL) return "DATE_FORMAT("+datefield+",'%e')";
			if (dbengine==MSSQL) return "DATEPART(day,"+datefield+")";
		}

		if (part.equals("month"))
		{
			if (dbengine==MYSQL) return "DATE_FORMAT("+datefield+",'%c')";
			if (dbengine==MSSQL) return "DATEPART(month,"+datefield+")";
		}

		if (part.equals("year"))
		{
			if (dbengine==MYSQL) return "DATE_FORMAT("+datefield+",'%Y')";
			if (dbengine==MSSQL) return "DATEPART(year,"+datefield+")";
		}

		return null;
	}

	public String getDaysFromNowSQL(String datefield)
	{
		if (dbengine==MYSQL) return "(TO_DAYS("+datefield+")-TO_DAYS(NOW()))";
		if (dbengine==MSSQL) return "DATEDIFF(dd,getdate(),"+datefield+")";

		return null;
	}




}

