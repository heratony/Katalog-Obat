package com.webprofusion.util.string;

import java.io.*;
import java.util.*;


public class StringUtils {

	public static String generateUniqueID(String ip,String seed)
	{

		java.util.Date createdDate = new java.util.Date();
		String dateAndTime = StringUtils.buildDateString(createdDate);
		String idstring=StringUtils.StripPunctuation(ip+dateAndTime+seed);
		if (idstring.length()>100) idstring=idstring.substring(1,100); //trim string if it's toooo long.
		return idstring;
	}


	//convert a given number of bytes in to the corresponding file size description
	public static String toFileSize(int fsize)
	{
		String filesize_str="";
		String filesize_left="",filesize_right="";
		if (fsize<1024) filesize_str=fsize+" Bytes";
		if (fsize>=1024) filesize_str=(int)(fsize/1024)+" KB";

		if ((fsize/1024)>=1024)
		{
			//round the number to 2 decimal places
			int precision=2;
			filesize_str=""+(double)(fsize/1024)/1024;
			int index=filesize_str.indexOf(".");
			if (index!=-1)
			{
				filesize_left=filesize_str.substring(0,index);
				if (filesize_str.length()>(index+precision+1)) filesize_right=filesize_str.substring(index,(index+precision+1));
				filesize_str=filesize_left+filesize_right+" MB";
			}
		}

		return filesize_str;
	}

	public static String buildDateString(java.util.Date d)
	{
		Calendar tmpCalendar=new GregorianCalendar();
		tmpCalendar.setTime(d);
		String r;
		r = (tmpCalendar.get(Calendar.MONTH)+1 )+ "/" +  tmpCalendar.get(Calendar.DAY_OF_MONTH) + "/" + tmpCalendar.get(Calendar.YEAR);
		r += " " +tmpCalendar.get(Calendar.HOUR_OF_DAY) + ":" +tmpCalendar.get(Calendar.MINUTE);
		return r;
	}

	public static String StripPunctuation(String s)
	{
		//
		// used to strip out , ' . etc
		//

		if (s==null)
			s = "";

		String r;
		char c;

		r = "";
		for (int i = 0; i < s.length(); i++)
		{
			c = s.charAt(i);
			if (c == '\'' || c==',' || c=='.' || c=='/' || c=='\\' || c==':' || c==' ') r += "";
			else r += c;
		}
		return r ;
	}

	public static String inQuotes(String s)
	{
		return "'"+makeSQLString(s)+"'";

	}

	public static String makeSQLString(String s)
	{
		//
		// use this when giving strings to SQL which need ' marks
		// around them and which must have any internal 's doubled
		//

		String result;
		char c;
		String test="'";

		if (s==null) s="";
		result = "";
		for (int i = 0; i < s.length(); i++)
		{
			c =  s.charAt(i);
			if (c == test.charAt(0)) result += "''";
			else result += c;
		}
		return result;

	}
}
