DBConnection Object

Welcome to the first opensource release of DBConnection, com.webprofusion.utli.db.DBConnection is a simple wrapper object for JDBC database connections and currently supports MySQL & MS SQL Server. Also included in this package are the classes com.webprofusion.utils.StringUtils and com.webprofusion.SiteProperties - The dbconnection object currently uses this class to load settings for the DB Connection at runtime (this lets you define a properties file which specifies the dbengine and connection info)

A Sample Site.properties file would look like (mySQL is set as the dbengine, sa is the user and mypass is the password) :

# 
# (c) WebProfusion
# Site properties file

#
# JDBC drivers for MS-SQL 7.0
#
#

# Penguin -SQL Server 7
#dbengine=0
#dbdrivername=com.inet.tds.TdsDriver
#dbconnstr=jdbc:inetdae:nt-fs-intdev?database=eg2&sql7=true

# mySQL
dbengine=1
dbdrivername=org.gjt.mm.mysql.Driver
dbconnstr=jdbc:mysql://localhost/penguin2?user=sa&password=mypass


An Example usage of the DBConnection object would be:

	String sql;
	DBConnection conn=new DBConnection();
	conn.open(); //do this before you use a new DBConnection..

	sql="insert into DiscussionMessages values ("+StringUtils.inQuotes(myname)+","+StringUtils.inQuotes(message)+","+conn.getCurrentDateSQL()+")";	
	conn.executeUpdate(sql);


	conn.close(); //always do this when finished using the DBConnection
Or :	

	DBConnection conn = new DBConnection();
	conn.open();

	String sql="select name from Users";

	conn.openQueryRS(sql); //use this to open your query results

	while(conn.rs.next()) //loop through results (if any)
	{
		System.out.println("hello "+conn.rs.getString("name"));
	}

	conn.closeQueryRS(); //always close result set
	conn.close();
	
You can perform any number of DBConnection.executeUpdate("...")  or DBConnection.openQueryRS("...") 
as long as you don't nest another operation inside an openQueryRS/closeQueryRS, if you need to nest a query, 
create a new DBConnection to handle it.
		
Have Fun, and let me know if you use it as I'd like to know if it's useful or if anyone has improvements.
Christopher Cook
christopher.cook@webprofusion.com